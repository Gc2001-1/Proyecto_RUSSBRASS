const token = localStorage.getItem('rusbrass_token');
const profesorNombre = localStorage.getItem('rusbrass_profesor');

if (!token) {
  window.location.href = 'index.html';
}

const userNameEl = document.getElementById('userName');
if (profesorNombre) {
  userNameEl.innerText = profesorNombre;
}

const sections = document.querySelectorAll('.section-panel');
const menuButtons = document.querySelectorAll('.menu-actions button');

function showSection(id) {
  sections.forEach(sec => sec.classList.toggle('hidden', sec.id !== id));
  menuButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.target === id));
}

function logout() {
  localStorage.removeItem('rusbrass_token');
  localStorage.removeItem('rusbrass_profesor');
  window.location.href = 'index.html';
}

async function fetchJSON(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.mensaje || 'Error en la petición');
  }
  return response.json();
}

async function loadBandas() {
  const bandas = await fetchJSON('http://localhost:3000/api/bandas', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const bandaSelect = document.getElementById('asistenciaBanda');
  const alumnoBandas = document.getElementById('alumnoBandas');
  bandaSelect.innerHTML = '';
  alumnoBandas.innerHTML = '';

  bandas.forEach(banda => {
    bandaSelect.innerHTML += `<option value="${banda.id_banda}">${banda.nombre_banda}</option>`;
    alumnoBandas.innerHTML += `<option value="${banda.id_banda}">${banda.nombre_banda}</option>`;
  });
}

async function loadAlumnos() {
  const alumnos = await fetchJSON('http://localhost:3000/api/alumnos', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const list = document.getElementById('alumnosList');
  const asistenciaAlumnos = document.getElementById('asistenciaAlumnos');
  list.innerHTML = '';
  asistenciaAlumnos.innerHTML = '';

  if (alumnos.length === 0) {
    list.innerHTML = '<p>No hay alumnos registrados.</p>';
    return;
  }

  list.innerHTML = alumnos.map(alumno => `
    <div class="card">
      <strong>${alumno.nombre}</strong>
      <p class="small">Teléfono: ${alumno.telefono || 'N/A'}</p>
      <p class="small">Bandas: ${alumno.bandas.map(b => b.nombre_banda).join(', ') || 'Sin bandas'}</p>
    </div>
  `).join('');

  asistenciaAlumnos.innerHTML = alumnos.map(alumno => `
    <label class="checkbox-item">
      <input type="checkbox" value="${alumno.id_alumno}" /> ${alumno.nombre}
    </label>
  `).join('');
}

async function loadBandasList() {
  const bandas = await fetchJSON('http://localhost:3000/api/bandas', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const list = document.getElementById('bandasList');
  list.innerHTML = '';

  if (bandas.length === 0) {
    list.innerHTML = '<p>No hay bandas registradas.</p>';
    return;
  }

  list.innerHTML = bandas.map(banda => `
    <div class="card">
      <strong>${banda.nombre_banda}</strong>
    </div>
  `).join('');
}

async function createAlumno(event) {
  event.preventDefault();
  const nombre = document.getElementById('alumnoNombre').value;
  const telefono = document.getElementById('alumnoTelefono').value;
  const direccion = document.getElementById('alumnoDireccion').value;
  const bandas = Array.from(document.getElementById('alumnoBandas').selectedOptions).map(opt => opt.value);
  const status = document.getElementById('alumnosStatus');

  try {
    await fetchJSON('http://localhost:3000/api/alumnos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ nombre, telefono, direccion, bandas })
    });
    status.innerText = 'Alumno registrado con éxito';
    status.className = 'status-message success';
    event.target.reset();
    await loadAlumnos();
  } catch (error) {
    status.innerText = error.message;
    status.className = 'status-message error';
  }
}

async function createBanda(event) {
  event.preventDefault();
  const nombre = document.getElementById('bandaNombre').value;
  const status = document.getElementById('bandasStatus');

  try {
    await fetchJSON('http://localhost:3000/api/bandas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ nombre_banda: nombre })
    });
    status.innerText = 'Banda creada con éxito';
    status.className = 'status-message success';
    event.target.reset();
    await loadBandas();
    await loadBandasList();
  } catch (error) {
    status.innerText = error.message;
    status.className = 'status-message error';
  }
}

async function registerAttendance(event) {
  event.preventDefault();
  const tipo = document.getElementById('asistenciaTipo').value;
  const id_banda = document.getElementById('asistenciaBanda').value;
  const descripcion = document.getElementById('asistenciaDescripcion').value;
  const asistencias = Array.from(document.querySelectorAll('#asistenciaAlumnos input[type="checkbox"]'))
    .map(checkbox => ({ id_alumno: Number(checkbox.value), asistio: checkbox.checked }));
  const status = document.getElementById('asistenciaStatus');

  const payload = { id_banda: Number(id_banda), descripcion, asistencias };
  if (tipo === 'presentacion') {
    payload.fecha = document.getElementById('asistenciaFecha').value;
    payload.lugar_presentacion = document.getElementById('asistenciaLugar').value;
  }

  try {
    await fetchJSON(`http://localhost:3000/api/asistencia/${tipo}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload)
    });
    status.innerText = 'Asistencia registrada con éxito';
    status.className = 'status-message success';
    event.target.reset();
    document.getElementById('presentacionFields').classList.add('hidden');
  } catch (error) {
    status.innerText = error.message;
    status.className = 'status-message error';
  }
}

document.getElementById('alumnoForm').addEventListener('submit', createAlumno);
document.getElementById('bandaForm').addEventListener('submit', createBanda);
document.getElementById('asistenciaForm').addEventListener('submit', registerAttendance);

document.getElementById('asistenciaTipo').addEventListener('change', event => {
  document.getElementById('presentacionFields').classList.toggle('hidden', event.target.value !== 'presentacion');
});

showSection('alumnosSection');
loadBandas();
loadAlumnos();
loadBandasList();