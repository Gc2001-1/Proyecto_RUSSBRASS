const express = require('express');
const router = express.Router();
const bandaController = require('../controllers/bandaController');
const { verificarToken } = require('../middlewares/authMiddleware');

router.get('/', verificarToken, bandaController.getBandas);
router.get('/:id', verificarToken, bandaController.getBandaById);
router.post('/', verificarToken, bandaController.createBanda);
router.put('/:id', verificarToken, bandaController.updateBanda);
router.delete('/:id', verificarToken, bandaController.deleteBanda);

module.exports = router;
