const express = require('express');
const router = express.Router();
const reporteController = require('../controllers/reporteController');
const { verificarToken } = require('../middlewares/authMiddleware');

router.get('/historial', verificarToken, reporteController.getHistorialAsistencia);
router.get('/resumen-bandas', verificarToken, reporteController.getResumenPorBanda);
router.get('/resumen-general', verificarToken, reporteController.getResumenGeneral);

module.exports = router;
