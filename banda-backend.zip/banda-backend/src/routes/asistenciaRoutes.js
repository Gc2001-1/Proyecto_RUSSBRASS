const express = require('express');
const router = express.Router();
const asistenciaController = require('../controllers/asistenciaController');
const { verificarToken } = require('../middlewares/authMiddleware');

// Proteger rutas con Token
router.post('/ensayo', verificarToken, asistenciaController.registrarAsistenciaEnsayo);
router.post('/presentacion', verificarToken, asistenciaController.registrarAsistenciaPresentacion);

module.exports = router;