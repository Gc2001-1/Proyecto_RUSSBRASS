const express = require('express');
const router = express.Router();
const profesorController = require('../controllers/profesorController');
const { verificarToken } = require('../middlewares/authMiddleware');

router.get('/', verificarToken, profesorController.getProfesores);
router.get('/:id', verificarToken, profesorController.getProfesorById);
router.post('/', verificarToken, profesorController.createProfesor);
router.put('/:id', verificarToken, profesorController.updateProfesor);
router.delete('/:id', verificarToken, profesorController.deleteProfesor);

module.exports = router;
