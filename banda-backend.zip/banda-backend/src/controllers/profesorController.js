const db = require('../config/db');
const bcrypt = require('bcryptjs');

const getProfesores = async (req, res) => {
    try {
        const result = await db.query(
            'SELECT id_profesor, nombre, correo, rol FROM public.profesor ORDER BY nombre ASC'
        );
        res.json(result.rows);
    } catch (error) {
        console.error('Error al obtener profesores:', error);
        res.status(500).json({ mensaje: 'Error al obtener la lista de profesores' });
    }
};

const getProfesorById = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await db.query(
            'SELECT id_profesor, nombre, correo, rol FROM public.profesor WHERE id_profesor = $1',
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ mensaje: 'Profesor no encontrado' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error al obtener profesor:', error);
        res.status(500).json({ mensaje: 'Error al obtener el profesor' });
    }
};

const createProfesor = async (req, res) => {
    const { nombre, correo, contrasena, rol } = req.body;

    if (!nombre || String(nombre).trim() === '') {
        return res.status(400).json({ mensaje: 'El nombre del profesor es obligatorio' });
    }

    if (!correo || String(correo).trim() === '') {
        return res.status(400).json({ mensaje: 'El correo del profesor es obligatorio' });
    }

    if (!contrasena || String(contrasena).trim() === '') {
        return res.status(400).json({ mensaje: 'La contraseña es obligatoria' });
    }

    try {
        const existe = await db.query(
            'SELECT id_profesor FROM public.profesor WHERE correo = $1',
            [String(correo).trim()]
        );

        if (existe.rows.length > 0) {
            return res.status(409).json({ mensaje: 'Ya existe un profesor con ese correo' });
        }

        const passwordHash = await bcrypt.hash(String(contrasena), 10);
        const result = await db.query(
            'INSERT INTO public.profesor (nombre, correo, contrasena, rol) VALUES ($1, $2, $3, $4) RETURNING id_profesor, nombre, correo, rol',
            [String(nombre).trim(), String(correo).trim(), passwordHash, rol || 'Profesor']
        );

        res.status(201).json({ mensaje: 'Profesor creado correctamente', profesor: result.rows[0] });
    } catch (error) {
        console.error('Error al crear profesor:', error);
        res.status(500).json({ mensaje: 'Error al crear el profesor' });
    }
};

const updateProfesor = async (req, res) => {
    const { id } = req.params;
    const { nombre, correo, contrasena, rol } = req.body;

    if (!nombre || String(nombre).trim() === '') {
        return res.status(400).json({ mensaje: 'El nombre del profesor es obligatorio' });
    }

    if (!correo || String(correo).trim() === '') {
        return res.status(400).json({ mensaje: 'El correo del profesor es obligatorio' });
    }

    try {
        const existe = await db.query(
            'SELECT id_profesor FROM public.profesor WHERE correo = $1 AND id_profesor <> $2',
            [String(correo).trim(), id]
        );

        if (existe.rows.length > 0) {
            return res.status(409).json({ mensaje: 'Ya existe otro profesor con ese correo' });
        }

        let query = 'UPDATE public.profesor SET nombre = $1, correo = $2, rol = $3';
        const params = [String(nombre).trim(), String(correo).trim(), rol || 'Profesor'];

        if (contrasena && String(contrasena).trim() !== '') {
            const passwordHash = await bcrypt.hash(String(contrasena), 10);
            query += ', contrasena = $4';
            params.push(passwordHash);
        }

        query += ' WHERE id_profesor = $' + (params.length + 1) + ' RETURNING id_profesor, nombre, correo, rol';
        params.push(id);

        const result = await db.query(query, params);

        if (result.rows.length === 0) {
            return res.status(404).json({ mensaje: 'Profesor no encontrado' });
        }

        res.json({ mensaje: 'Profesor actualizado correctamente', profesor: result.rows[0] });
    } catch (error) {
        console.error('Error al actualizar profesor:', error);
        res.status(500).json({ mensaje: 'Error al actualizar el profesor' });
    }
};

const deleteProfesor = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await db.query(
            'DELETE FROM public.profesor WHERE id_profesor = $1 RETURNING id_profesor',
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ mensaje: 'Profesor no encontrado' });
        }

        res.json({ mensaje: 'Profesor eliminado correctamente' });
    } catch (error) {
        console.error('Error al eliminar profesor:', error);
        res.status(500).json({ mensaje: 'Error al eliminar el profesor' });
    }
};

module.exports = {
    getProfesores,
    getProfesorById,
    createProfesor,
    updateProfesor,
    deleteProfesor
};
