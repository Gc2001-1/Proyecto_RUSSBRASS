const db = require('../config/db');

// Obtener todos los alumnos con las bandas a las que pertenecen
const getAlumnos = async (req, res) => {
    try {
        const query = `
      SELECT 
        a.id_alumno, 
        a.nombre, 
        a.telefono, 
        a.direccion, 
        a.fecha_inscripcion,
        COALESCE(
          json_agg(
            json_build_object('id_banda', b.id_banda, 'nombre_banda', b.nombre_banda)
          ) FILTER (WHERE b.id_banda IS NOT NULL), '[]'
        ) AS bandas
      FROM public.alumno a
      LEFT JOIN public.alumno_banda ab ON a.id_alumno = ab.id_alumno
      LEFT JOIN public.banda b ON ab.id_banda = b.id_banda
      GROUP BY a.id_alumno
      ORDER BY a.nombre ASC;
    `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (error) {
        console.error('Error al obtener alumnos:', error);
        res.status(500).json({ mensaje: 'Error al obtener lista de alumnos' });
    }
};

// Crear un nuevo alumno y asignarlo a 1 o más bandas
const createAlumno = async (req, res) => {
    const { nombre, telefono, direccion, bandas } = req.body;

    if (!nombre || String(nombre).trim() === '') {
        return res.status(400).json({ mensaje: 'El nombre del alumno es obligatorio' });
    }

    if (telefono && String(telefono).trim() !== '' && String(telefono).trim().length < 8) {
        return res.status(400).json({ mensaje: 'El teléfono debe tener al menos 8 caracteres' });
    }

    try {
        // Iniciar transacción
        await db.query('BEGIN');

        const alumnoResult = await db.query(
            'INSERT INTO public.alumno (nombre, telefono, direccion) VALUES ($1, $2, $3) RETURNING *',
            [nombre, telefono, direccion]
        );

        const nuevoAlumno = alumnoResult.rows[0];

        if (bandas && Array.isArray(bandas) && bandas.length > 0) {
            for (const id_banda of bandas) {
                await db.query(
                    'INSERT INTO public.alumno_banda (id_alumno, id_banda) VALUES ($1, $2)',
                    [nuevoAlumno.id_alumno, id_banda]
                );
            }
        }

        // Confirmar cambios
        await db.query('COMMIT');
        res.status(201).json({ mensaje: 'Alumno registrado con éxito', alumno: nuevoAlumno });
    } catch (error) {
        // Revertir cambios si hay error
        await db.query('ROLLBACK');
        console.error('Error al crear alumno:', error);
        res.status(500).json({ mensaje: 'Error al registrar el alumno' });
    }
};
// Eliminar un alumno
const deleteAlumno = async (req, res) => {
    const { id } = req.params;

    try {
        await db.query('BEGIN');
        await db.query('DELETE FROM public.alumno_banda WHERE id_alumno = $1', [id]);
        await db.query('DELETE FROM public.alumno WHERE id_alumno = $1', [id]);
        await db.query('COMMIT');
        res.json({ mensaje: 'Alumno eliminado correctamente' });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error('Error al eliminar alumno:', error);
        res.status(500).json({ mensaje: 'Error al eliminar el alumno' });
    }
};

const updateAlumno = async (req, res) => {
    const { id } = req.params;
    const { nombre, telefono, direccion, bandas } = req.body;

    if (!nombre || String(nombre).trim() === '') {
        return res.status(400).json({ mensaje: 'El nombre del alumno es obligatorio' });
    }

    try {
        await db.query('BEGIN');

        const result = await db.query(
            'UPDATE public.alumno SET nombre = $1, telefono = $2, direccion = $3 WHERE id_alumno = $4 RETURNING *',
            [String(nombre).trim(), telefono || null, direccion || null, id]
        );

        if (result.rows.length === 0) {
            await db.query('ROLLBACK');
            return res.status(404).json({ mensaje: 'Alumno no encontrado' });
        }

        await db.query('DELETE FROM public.alumno_banda WHERE id_alumno = $1', [id]);

        if (bandas && Array.isArray(bandas) && bandas.length > 0) {
            for (const id_banda of bandas) {
                await db.query(
                    'INSERT INTO public.alumno_banda (id_alumno, id_banda) VALUES ($1, $2)',
                    [id, id_banda]
                );
            }
        }

        await db.query('COMMIT');
        res.json({ mensaje: 'Alumno actualizado correctamente' });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error('Error al actualizar alumno:', error);
        res.status(500).json({ mensaje: 'Error al actualizar el alumno' });
    }
};

// Obtener un alumno por su ID
const getAlumnoById = async (req, res) => {
    const { id } = req.params;

    try {
        const query = `
      SELECT 
        a.id_alumno, 
        a.nombre, 
        a.telefono, 
        a.direccion, 
        a.fecha_inscripcion,
        COALESCE(
          json_agg(
            json_build_object('id_banda', b.id_banda, 'nombre_banda', b.nombre_banda)
          ) FILTER (WHERE b.id_banda IS NOT NULL), '[]'
        ) AS bandas
      FROM public.alumno a
      LEFT JOIN public.alumno_banda ab ON a.id_alumno = ab.id_alumno
      LEFT JOIN public.banda b ON ab.id_banda = b.id_banda
      WHERE a.id_alumno = $1
      GROUP BY a.id_alumno;
    `;
        const result = await db.query(query, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ mensaje: 'Alumno no encontrado' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error al obtener el alumno:', error);
        res.status(500).json({ mensaje: 'Error al obtener el alumno' });
    }
};


module.exports = {
    getAlumnos,
    createAlumno,
    deleteAlumno,
    updateAlumno,
    getAlumnoById
};