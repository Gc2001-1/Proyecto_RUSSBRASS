const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const login = async (req, res) => {
    const { correo, contrasena } = req.body;

    if (!correo || String(correo).trim() === '' || !contrasena || String(contrasena).trim() === '') {
        return res.status(400).json({ mensaje: 'Correo y contraseña son obligatorios' });
    }

    try {
        const result = await db.query('SELECT * FROM public.profesor WHERE correo = $1', [correo]);

        if (result.rows.length === 0) {
            return res.status(400).json({ mensaje: 'Correo o contraseña incorrectos' });
        }

        const profesor = result.rows[0];

        // Compara contraseña en texto plano o hash encriptado
        const esValida = contrasena === profesor.contrasena || await bcrypt.compare(contrasena, profesor.contrasena);

        if (!esValida) {
            return res.status(401).json({ mensaje: 'Correo o contraseña incorrectos' });
        }

        const token = jwt.sign(
            { id_profesor: profesor.id_profesor, nombre: profesor.nombre, correo: profesor.correo, rol: profesor.rol },
            process.env.JWT_SECRET,
            { expiresIn: '8h' }
        );

        res.json({
            mensaje: 'Inicio de sesión exitoso',
            token,
            profesor: {
                id_profesor: profesor.id_profesor,
                nombre: profesor.nombre,
                correo: profesor.correo,
                rol: profesor.rol
            }
        });

    } catch (error) {
        console.error('Error en el login:', error);
        res.status(500).json({ mensaje: 'Error en el servidor al intentar iniciar sesión' });
    }
};

module.exports = { login };