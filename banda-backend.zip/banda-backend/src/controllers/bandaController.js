const db = require('../config/db');

const getBandas = async (req, res) => {
    try {
        const result = await db.query(
            'SELECT id_banda, nombre_banda FROM public.banda ORDER BY nombre_banda ASC'
        );

        res.json(result.rows);
    } catch (error) {
        console.error('Error al obtener bandas:', error);
        res.status(500).json({ mensaje: 'Error al obtener la lista de bandas' });
    }
};

const getBandaById = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await db.query(
            'SELECT id_banda, nombre_banda FROM public.banda WHERE id_banda = $1',
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ mensaje: 'Banda no encontrada' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error al obtener la banda:', error);
        res.status(500).json({ mensaje: 'Error al obtener la banda' });
    }
};

const createBanda = async (req, res) => {
    const { nombre_banda } = req.body;

    if (!nombre_banda || String(nombre_banda).trim() === '') {
        return res.status(400).json({ mensaje: 'El nombre de la banda es obligatorio' });
    }

    try {
        const existe = await db.query(
            'SELECT id_banda FROM public.banda WHERE LOWER(nombre_banda) = LOWER($1)',
            [String(nombre_banda).trim()]
        );

        if (existe.rows.length > 0) {
            return res.status(409).json({ mensaje: 'La banda ya existe' });
        }

        const result = await db.query(
            'INSERT INTO public.banda (nombre_banda) VALUES ($1) RETURNING id_banda, nombre_banda',
            [String(nombre_banda).trim()]
        );

        res.status(201).json({
            mensaje: 'Banda creada correctamente',
            banda: result.rows[0]
        });
    } catch (error) {
        console.error('Error al crear la banda:', error);
        res.status(500).json({ mensaje: 'Error al crear la banda' });
    }
};

const updateBanda = async (req, res) => {
    const { id } = req.params;
    const { nombre_banda } = req.body;

    if (!nombre_banda || String(nombre_banda).trim() === '') {
        return res.status(400).json({ mensaje: 'El nombre de la banda es obligatorio' });
    }

    try {
        const existe = await db.query(
            'SELECT id_banda FROM public.banda WHERE LOWER(nombre_banda) = LOWER($1) AND id_banda <> $2',
            [String(nombre_banda).trim(), id]
        );

        if (existe.rows.length > 0) {
            return res.status(409).json({ mensaje: 'Ya existe otra banda con ese nombre' });
        }

        const result = await db.query(
            'UPDATE public.banda SET nombre_banda = $1 WHERE id_banda = $2 RETURNING id_banda, nombre_banda',
            [String(nombre_banda).trim(), id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ mensaje: 'Banda no encontrada' });
        }

        res.json({
            mensaje: 'Banda actualizada correctamente',
            banda: result.rows[0]
        });
    } catch (error) {
        console.error('Error al actualizar la banda:', error);
        res.status(500).json({ mensaje: 'Error al actualizar la banda' });
    }
};

const deleteBanda = async (req, res) => {
    const { id } = req.params;

    try {
        await db.query('BEGIN');
        await db.query('DELETE FROM public.alumno_banda WHERE id_banda = $1', [id]);

        const result = await db.query(
            'DELETE FROM public.banda WHERE id_banda = $1 RETURNING id_banda',
            [id]
        );

        if (result.rowCount === 0) {
            await db.query('ROLLBACK');
            return res.status(404).json({ mensaje: 'Banda no encontrada' });
        }

        await db.query('COMMIT');
        res.json({ mensaje: 'Banda eliminada correctamente' });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error('Error al eliminar la banda:', error);
        res.status(500).json({ mensaje: 'Error al eliminar la banda' });
    }
};

module.exports = {
    getBandas,
    getBandaById,
    createBanda,
    updateBanda,
    deleteBanda
};
