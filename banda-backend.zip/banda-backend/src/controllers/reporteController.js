const db = require('../config/db');

const getHistorialAsistencia = async (req, res) => {
    const { id_alumno, id_banda, fecha, tipo } = req.query;

    let query = `
        SELECT 
            a.id_alumno,
            a.nombre AS alumno,
            b.id_banda,
            b.nombre_banda,
            e.id_ensayo AS id_evento,
            COALESCE(e.descripcion, 'Sin descripción') AS descripcion,
            e.id_profesor,
            ae.asistio,
            e.fecha_registro,
            CASE WHEN e.id_ensayo IS NOT NULL THEN 'ensayo' ELSE 'presentacion' END AS tipo_evento
        FROM public.asistencia_ensayo ae
        INNER JOIN public.ensayo e ON ae.id_ensayo = e.id_ensayo
        INNER JOIN public.alumno a ON ae.id_alumno = a.id_alumno
        INNER JOIN public.banda b ON e.id_banda = b.id_banda
    `;

    const conditions = [];
    const params = [];

    if (id_alumno) {
        conditions.push(`a.id_alumno = $${params.length + 1}`);
        params.push(id_alumno);
    }

    if (id_banda) {
        conditions.push(`b.id_banda = $${params.length + 1}`);
        params.push(id_banda);
    }

    if (fecha) {
        conditions.push(`DATE(e.fecha_registro) = DATE($${params.length + 1})`);
        params.push(fecha);
    }

    if (tipo) {
        conditions.push(`LOWER(CASE WHEN e.id_ensayo IS NOT NULL THEN 'ensayo' ELSE 'presentacion' END) = LOWER($${params.length + 1})`);
        params.push(tipo);
    }

    if (conditions.length > 0) {
        query += ` WHERE ${conditions.join(' AND ')}`;
    }

    query += ` ORDER BY e.fecha_registro DESC, a.nombre ASC`;

    try {
        const result = await db.query(query, params);
        res.json({
            total: result.rows.length,
            filtros: { id_alumno: id_alumno || null, id_banda: id_banda || null, fecha: fecha || null, tipo: tipo || null },
            datos: result.rows
        });
    } catch (error) {
        console.error('Error al obtener historial:', error);
        res.status(500).json({ mensaje: 'Error al obtener el historial de asistencia' });
    }
};

const getResumenPorBanda = async (req, res) => {
    try {
        const result = await db.query(`
            SELECT 
                b.id_banda,
                b.nombre_banda,
                COUNT(DISTINCT ab.id_alumno) AS total_alumnos,
                COUNT(DISTINCT CASE WHEN ae.asistio = true THEN ae.id_alumno END) AS asistencias,
                COUNT(DISTINCT CASE WHEN ae.asistio = false THEN ae.id_alumno END) AS faltas
            FROM public.banda b
            LEFT JOIN public.alumno_banda ab ON ab.id_banda = b.id_banda
            LEFT JOIN public.asistencia_ensayo ae ON ae.id_alumno = ab.id_alumno
            GROUP BY b.id_banda, b.nombre_banda
            ORDER BY b.nombre_banda ASC
        `);

        res.json({
            total_bandas: result.rows.length,
            datos: result.rows
        });
    } catch (error) {
        console.error('Error al obtener resumen por banda:', error);
        res.status(500).json({ mensaje: 'Error al obtener el resumen por banda' });
    }
};

const getResumenGeneral = async (req, res) => {
    try {
        const result = await db.query(`
            SELECT 
                COUNT(DISTINCT a.id_alumno) AS total_alumnos,
                COUNT(DISTINCT b.id_banda) AS total_bandas,
                COUNT(DISTINCT p.id_profesor) AS total_profesores,
                COUNT(DISTINCT ae.id_ensayo) AS total_ensayos
            FROM public.alumno a
            CROSS JOIN public.banda b
            LEFT JOIN public.profesor p ON true
            LEFT JOIN public.ensayo ae ON true
        `);

        res.json({ resumen: result.rows[0] });
    } catch (error) {
        console.error('Error al obtener resumen general:', error);
        res.status(500).json({ mensaje: 'Error al obtener el resumen general' });
    }
};

module.exports = {
    getHistorialAsistencia,
    getResumenPorBanda,
    getResumenGeneral
};
