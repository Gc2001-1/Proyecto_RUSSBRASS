const db = require('../config/db');

// Registrar un Ensayo y guardar la asistencia de la lista de alumnos
const registrarAsistenciaEnsayo = async (req, res) => {
    const { id_banda, descripcion, asistencias } = req.body;
    // asistencias debe ser un arreglo de objetos: [{ id_alumno: 1, asistio: true }, { id_alumno: 2, asistio: false }]
    const id_profesor = req.profesor.id_profesor; // Obtenido del token JWT

    try {
        // 1. Crear el registro del ensayo
        const ensayoResult = await db.query(
            'INSERT INTO public.ensayo (id_banda, id_profesor, descripcion) VALUES ($1, $2, $3) RETURNING id_ensayo',
            [id_banda, id_profesor, descripcion || null]
        );

        const id_ensayo = ensayoResult.rows[0].id_ensayo;

        // 2. Insertar la asistencia de cada alumno
        if (asistencias && Array.isArray(asistencias) && asistencias.length > 0) {
            for (const item of asistencias) {
                await db.query(
                    'INSERT INTO public.asistencia_ensayo (id_ensayo, id_alumno, asistio) VALUES ($1, $2, $3)',
                    [id_ensayo, item.id_alumno, item.asistio]
                );
            }
        }

        res.status(201).json({ mensaje: 'Asistencia de ensayo registrada con éxito', id_ensayo });
    } catch (error) {
        console.error('Error al registrar asistencia de ensayo:', error);
        res.status(500).json({ mensaje: 'Error al guardar la asistencia del ensayo' });
    }
};

// Registrar una Presentación y guardar la asistencia de la lista de alumnos
const registrarAsistenciaPresentacion = async (req, res) => {
    const { id_banda, fecha, lugar_presentacion, asistencias } = req.body;

    try {
        // 1. Crear la presentación
        const presResult = await db.query(
            'INSERT INTO public.presentacion (fecha, lugar_presentacion, id_banda) VALUES ($1, $2, $3) RETURNING id_presentacion',
            [fecha, lugar_presentacion, id_banda]
        );

        const id_presentacion = presResult.rows[0].id_presentacion;

        // 2. Insertar la asistencia de cada alumno
        if (asistencias && Array.isArray(asistencias) && asistencias.length > 0) {
            for (const item of asistencias) {
                await db.query(
                    'INSERT INTO public.asistencia_presentacion (id_presentacion, id_alumno, asistio) VALUES ($1, $2, $3)',
                    [id_presentacion, item.id_alumno, item.asistio]
                );
            }
        }

        res.status(201).json({ mensaje: 'Asistencia de presentación registrada con éxito', id_presentacion });
    } catch (error) {
        console.error('Error al registrar asistencia de presentación:', error);
        res.status(500).json({ mensaje: 'Error al guardar la asistencia de la presentación' });
    }
};

module.exports = {
    registrarAsistenciaEnsayo,
    registrarAsistenciaPresentacion
};