# Documentación de API

## Base URL

```text
http://localhost:3000
```

## Autenticación

Todas las rutas de alumnos y asistencia requieren un token JWT en el encabezado `Authorization`.

```http
Authorization: Bearer <token>
```

## Endpoints

### POST /api/auth/login

Autentica a un profesor y devuelve un token JWT.

**Body**

```json
{
  "correo": "profesor@ejemplo.com",
  "contrasena": "123456"
}
```

**Respuesta exitosa**

```json
{
  "mensaje": "Inicio de sesión exitoso",
  "token": "...",
  "profesor": {
    "id_profesor": 1,
    "nombre": "Profesor A",
    "correo": "profesor@ejemplo.com",
    "rol": "Profesor"
  }
}
```

### GET /api/alumnos

Obtiene la lista de alumnos con sus bandas asociadas.

### GET /api/alumnos/:id

Obtiene un alumno específico por su ID.

### POST /api/alumnos

Crea un nuevo alumno y lo asocia a una o varias bandas.

**Body**

```json
{
  "nombre": "Juan Pérez",
  "telefono": "12345678",
  "direccion": "Ciudad",
  "bandas": [1, 2]
}
```

### DELETE /api/alumnos/:id

Elimina un alumno por su ID.

### POST /api/asistencia/ensayo

Registra la asistencia de alumnos en un ensayo.

**Body**

```json
{
  "id_banda": 1,
  "descripcion": "Ensayo semanal",
  "asistencias": [
    { "id_alumno": 1, "asistio": true },
    { "id_alumno": 2, "asistio": false }
  ]
}
```

### POST /api/asistencia/presentacion

Registra la asistencia de alumnos en una presentación.

**Body**

```json
{
  "id_banda": 1,
  "fecha": "2026-08-10",
  "lugar_presentacion": "Auditorio principal",
  "asistencias": [
    { "id_alumno": 1, "asistio": true },
    { "id_alumno": 2, "asistio": false }
  ]
}
```
