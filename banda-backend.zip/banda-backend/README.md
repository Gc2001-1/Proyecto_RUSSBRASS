# Banda Backend

## Descripción general

Este proyecto es el backend de una aplicación web orientada a la gestión de asistencia de alumnos para profesores. Su propósito es permitir registrar asistencia de forma digital, organizar información de alumnos y bandas, y ofrecer un sistema seguro mediante autenticación con JWT.

Desarrollado como parte del proceso de horas sociales por Moisés David García Casco, carnet GC251462, en la Fundación SumbraSS.

## Objetivo del proyecto

Desarrollar una solución backend funcional que facilite a los profesores el registro y seguimiento de asistencia de los alumnos, reduciendo el uso de métodos manuales y mejorando la organización de la información.

## Funcionalidades actuales

- Autenticación de profesores mediante login.
- Generación y validación de tokens JWT.
- Protección de rutas privadas.
- Gestión de alumnos: listar, crear, consultar por ID y eliminar.
- Registro de asistencia para ensayos y presentaciones.
- Conexión con PostgreSQL.

## Tecnologías utilizadas

- Node.js
- Express.js
- PostgreSQL
- JWT
- bcryptjs
- dotenv
- cors

## Requisitos previos

- Node.js 18 o superior
- npm
- PostgreSQL instalado y en ejecución
- Una base de datos configurada con las tablas necesarias

## Instalación

1. Clona o entra en la carpeta del proyecto.
2. Instala las dependencias:

```bash
npm install
```

3. Crea un archivo `.env` a partir del ejemplo proporcionado en `.env.example`.
4. Ajusta las variables de entorno según tu configuración local.
5. Inicia el servidor:

```bash
npm run dev
```

O de forma simple:

```bash
npm start
```

## Variables de entorno

El proyecto utiliza las siguientes variables:

- `PORT`: puerto del servidor.
- `DB_USER`: usuario de PostgreSQL.
- `DB_PASSWORD`: contraseña de PostgreSQL.
- `DB_HOST`: host de PostgreSQL.
- `DB_PORT`: puerto de PostgreSQL.
- `DB_NAME`: nombre de la base de datos.
- `JWT_SECRET`: clave secreta para firmar los tokens JWT.

## Estructura del proyecto

```text
banda-backend/
├── server.js
├── package.json
├── .env
├── .env.example
├── src/
│   ├── config/
│   │   └── db.js
│   ├── controllers/
│   │   ├── alumnoController.js
│   │   ├── asistenciaController.js
│   │   └── authController.js
│   ├── middlewares/
│   │   └── authMiddleware.js
│   └── routes/
│       ├── alumnoRoutes.js
│       ├── asistenciaRoutes.js
│       └── authRoutes.js
└── test.http
```

## Base de datos

El backend espera trabajar con tablas como:

- `public.profesor`
- `public.alumno`
- `public.banda`
- `public.alumno_banda`
- `public.ensayo`
- `public.asistencia_ensayo`
- `public.presentacion`
- `public.asistencia_presentacion`

Estas tablas deben existir en PostgreSQL para que las consultas funcionen correctamente.

## Endpoints principales

### Autenticación

#### Login

- Método: `POST`
- Ruta: `/api/auth/login`
- Cuerpo:

```json
{
  "correo": "profesor@ejemplo.com",
  "contrasena": "123456"
}
```

### Alumnos

#### Obtener todos los alumnos

- Método: `GET`
- Ruta: `/api/alumnos`
- Requiere: token JWT en el header `Authorization`

#### Obtener un alumno por ID

- Método: `GET`
- Ruta: `/api/alumnos/:id`
- Requiere: token JWT

#### Crear alumno

- Método: `POST`
- Ruta: `/api/alumnos`
- Requiere: token JWT
- Ejemplo de cuerpo:

```json
{
  "nombre": "Juan Pérez",
  "telefono": "12345678",
  "direccion": "Ciudad",
  "bandas": [1, 2]
}
```

#### Eliminar alumno

- Método: `DELETE`
- Ruta: `/api/alumnos/:id`
- Requiere: token JWT

### Asistencia

#### Registrar asistencia de ensayo

- Método: `POST`
- Ruta: `/api/asistencia/ensayo`
- Requiere: token JWT

Ejemplo:

```json
{
  "id_banda": 1,
  "descripcion": "Ensayo semanal",
  "asistencias": [
    { "id_alumno": 1, "asistio": true },
    { "id_alumno": 2, "asistio": false }
  ]
}
```

#### Registrar asistencia de presentación

- Método: `POST`
- Ruta: `/api/asistencia/presentacion`
- Requiere: token JWT

Ejemplo:

```json
{
  "id_banda": 1,
  "fecha": "2026-08-10",
  "lugar_presentacion": "Auditorio principal",
  "asistencias": [
    { "id_alumno": 1, "asistio": true },
    { "id_alumno": 2, "asistio": true }
  ]
}
```

## Ejemplos de uso con curl

### Login

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"correo":"profesor@ejemplo.com","contrasena":"123456"}'
```

### Obtener alumnos

```bash
curl http://localhost:3000/api/alumnos \
  -H "Authorization: Bearer TU_TOKEN"
```

## Estado actual del proyecto

El proyecto se encuentra en una etapa inicial de desarrollo, pero ya cuenta con una base funcional para autenticación, gestión de alumnos y registro de asistencia. A futuro se pueden agregar más módulos como gestión completa de bandas, profesores y reportes.

## Próximos pasos sugeridos

- Implementar CRUD de bandas.
- Implementar CRUD de profesores.
- Mejorar validaciones de entrada.
- Añadir reportes y consultas históricas.
- Desarrollar la interfaz web para los profesores.

## Notas

- El archivo `.env` contiene datos sensibles y no debe compartirse públicamente.
- El archivo `test.http` sirve como referencia rápida para probar los endpoints.
